<img src="/assets/img/logo.svg" width="16%" />

# xmake <small>2.7.9</small>

> A cross-platform build utility based on Lua

- *Simple, Fast and Lightweight*
- *Modern C/C++ build tools, Powerful dependency package integration*

[Gitee](https://gitee.com/tboox/xmake/)
[Github](https://github.com/xmake-io/xmake/)
[Getting Started](/getting_started)

