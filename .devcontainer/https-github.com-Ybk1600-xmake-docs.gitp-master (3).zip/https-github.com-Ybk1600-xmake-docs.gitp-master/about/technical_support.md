# Technical support

You can also consider sponsoring us to get extra technical support services via the [Github sponsor program](https://github.com/sponsors/waruqi). If you do, you can get access to the [xmake-io/technical-support](https://github.com/xmake-io/technical-support) repository, which has the following bennefits:

- [X] Handling Issues with higher priority (**$50/month**)
- [X] One-to-one technical consulting service (**$50/month**)
- [X] Review your xmake.lua and provide suggestions for improvement (**$200/month**)

If you want to provide sponsorship through other ways, you can also request technical support and more information by emailing me at [waruqi@gmail.com](mailto:waruqi@gmail.com).
