
你也可以考虑通过 [Github 的赞助计划](https://github.com/sponsors/waruqi) 赞助我们来获取额外的技术支持服务，然后你就能获取 [xmake-io/technical-support](https://github.com/xmake-io/technical-support) 仓库的访问权限，获取更多技术咨询相关的信息。

- [x] 更高优先级的 Issues 问题处理 (**$50/month**)
- [x] Review xmake.lua 并提供改进建议 (**$50/month**)
- [x] 一对一技术咨询服务 (**$200/month**)

如果你打算通过其他渠道提供赞助，也可以通过发邮件给我们：[waruqi@gmail.com](mailto:waruqi@gmail.com) 来请求技术支持，并获取更多相关信息。
