## 周边物品

这里会不定期推出一些 xmake 相关的限量版周边纪念物品。

当然考虑到成本问题，作者目前还没能力免费提供，因此所有周边物品还是需要收取一些费用，但基本上都是成本价+运费，也会有一些微薄的收益用于支持项目的持续发展。

有需要的同学可以微信联系（waruqi）来预定。

付款方式可以看下这里：[赞助](https://xmake.io/#/zh-cn/about/sponsor)，或者直接微信转账。

### 限量版金边马克杯（带盖勺🥄）

价格：¥68（包邮）

<img src="/assets/img/xmake-cup.jpeg" width="80%" height="80%">

实物：

<img src="/assets/img/xmake-cup2.jpeg" width="35%" height="35%">
<img src="/assets/img/xmake-cup4.jpeg" width="30%" height="30%">
