
* 邮箱：[waruqi@gmail.com](mailto:waruqi@gmail.com)
* 主页：[xmake.io](https://xmake.io/#/zh-cn/)
* 社区
  - [Reddit论坛](https://www.reddit.com/r/xmake/)
  - [Telegram群组](https://t.me/tbooxorg)
  - [Discord聊天室](https://discord.gg/xmake)
  - QQ群：343118190, 662147501
* 源码：[Github](https://github.com/xmake-io/xmake), [Gitee](https://gitee.com/tboox/xmake)
* 微信公众号：tboox-os

