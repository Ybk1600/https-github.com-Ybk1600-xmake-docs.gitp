<img src="/assets/img/logo.svg" width="16%" />

# xmake <small>2.7.9</small>

> 一个基于Lua的轻量级跨平台自动构建工具

- *简单，快速，轻量无依赖*
- *现代化的 C/C++ 构建工具，强大的依赖包管理和集成*

[Gitee](https://gitee.com/tboox/xmake/)
[GitHub](https://github.com/xmake-io/xmake/)
[快速开始](/zh-cn/getting_started)
